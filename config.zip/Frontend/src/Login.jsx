import React, { useState } from 'react';
import axios from 'axios'
import toast  from 'react-hot-toast';
import { NavLink, useNavigate} from "react-router-dom"
const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginMessage, setLoginMessage] = useState('');
  const [auth,setAuth]=useState({
    user: null,
    token: "",})
  const handleLogin = async () => {

    try {
      const res = await axios.post(`${process.env.REACT_APP_API}/api/v1/auth/login`,
      {
        email,password
      })
      if (res && res.data.success) {
        toast.success(res.data && res.data.message);
        setAuth({
          ...auth,
          user: res.data.user,
          token: res.data.token,
        });
        navigate/Form.jsx
      }
      else {
        toast.error(res.data.message);
      }
    } catch (error) {
      console.log(error);
      toast.error("something went wrong");
    }
   

  };

  return (
      <section class="bg-gray-50 dark:bg-gray-900">
  <div class="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
      <a href="#" class="flex items-center mb-6 text-2xl  w-72 font-semibold text-gray-900 h-40 dark:text-white">
          <img className="mr-2" src="https://levitation.in/wp-content/uploads/2023/04/levitation-Infotech.png" alt="logo"/>
          
      </a>
      <div class="w-full bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
          <div class="p-6 space-y-4 md:space-y-6 sm:p-8">
              <h1 class="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white">
                  Sign in to your account
              </h1>
              <form class="space-y-4 md:space-y-6" action="#">
                  <div>
                      <label for="email" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Your email</label>
                      <input type="email" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="" 
                      value={email}
                      onChange={(e)=>setEmail(e.target.value)}  
                      required=""/>
                  </div>
                  <div>
                      <label for="password" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Password</label>
                      <input type="password" name="password" id="password" placeholder="" class="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required="" value={password}
                      onChange={(e)=>setPassword(e.target.value)}/>
                  </div>
                  <div class="flex items-center justify-between">
                      <div class="flex items-start">
                          
                      </div>
                      <NavLink to="/forgetpassword" class="text-sm font-medium text-primary-600 hover:underline dark:text-primary-500">Forgot password?</NavLink>
                  </div>
                  <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 focus:outline-none dark:focus:ring-blue-800 w-full" onClick={handleLogin}>LOGIN</button>
              </form>
              {loginMessage && <div className="text-red-500 mt-2">{loginMessage}</div>}
          </div>
      </div>
      
  </div>
</section>
  );
};

export default Login;


{/* <div className="flex justify-center items-center bg-gray-200  h-screen">
      <div className="w-96 bg-slate-200 shadow hover:shadow-cyan-700 rounded px-8 pt-6 pb-8 mb-4">
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
            Email
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="email"
            type="email"
            placeholder="Enter your Email"
            value={email}
            onChange={(e)=>setEmail(e.target.value)}
          />
          <label className="block text-gray-700 text-sm font-bold mb-2 mt-3" htmlFor="password">
            Password
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="password"
            type="password"
            placeholder="Enter your Password"
            value={password}
            onChange={(e)=>setPassword(e.target.value)}
          />
        </div>
        <div className="flex items-center justify-between">
          <button
            className="bg-cyan-500 shadow-lg w-96 shadow-blue-500/50 hover:bg-cyan-700 hover:rounded-full text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            type="button"
            onClick={handleLogin}
          >
            LOGIN
          </button>
        </div>
        {loginMessage && <div className="text-red-500 mt-2">{loginMessage}</div>}
        {/* {loginMessage &&response.ok && <p className="text-green-500 mt-2">{loginMessage}</p>} */}
      {/* </div>
    </div> */} 